// match.[ch] module:
//	Provides string matching support functions

// prototypes go here.. you'll need to maintain them as usual
extern char * matchwords( char *target, char **wds );
