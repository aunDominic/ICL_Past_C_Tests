extern void testcond( bool condition, char * testname );
extern void testint( int got, int expected, char * testname );
extern void testchar( char got, char expected, char * testname );
extern void testlong( long got, long expected, char * testname );
extern void testdouble( double got, double expected, char * testname );
extern void teststring( char * got, char * expected, char * testname );
