#ifndef __TESTS_H__
#define __TESTS_H__

#include "criterion/criterion.h"

#define ARR_SIZE(X) (sizeof(X)/sizeof(X[0]))

#endif
